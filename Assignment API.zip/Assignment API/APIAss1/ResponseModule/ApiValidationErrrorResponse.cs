﻿namespace APIAss1.ResponseModule
{
    public class ApiValidationErrrorResponse : ApiResponse
    {
        public ApiValidationErrrorResponse(): base(400)
        {
        
        }
        public IEnumerable<string> Errors { get; set; }

    }

}
