﻿using APIAss1.Dtos;
using AutoMapper;
using Core.Entities;

namespace APIAss1.Helpers
{
    public class ProductUrlResolver : IValueResolver<Product, ProductDto, string>
    {
        private readonly IConfiguration configuration;

        public ProductUrlResolver(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        public string Resolve(Product source, ProductDto destination, string destMember, ResolutionContext context)
        {
            if(!string.IsNullOrEmpty(source.PictureUrl))
                return this.configuration["ApiUrl"] + source.PictureUrl;

            return null;

        }
    }
}
