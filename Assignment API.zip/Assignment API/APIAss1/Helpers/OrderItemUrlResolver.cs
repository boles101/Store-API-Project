﻿using APIAss1.Dtos;
using AutoMapper;
using Core.Entities;
using Core.Entities.OrderAggregate;

namespace APIAss1.Helpers
{

        public class OrderItemUrlResolver : IValueResolver<OrderItem, OrderItemDto, string>
        {
            private readonly IConfiguration configuration;

            public OrderItemUrlResolver(IConfiguration configuration)
            {
                this.configuration = configuration;
            }
            public string Resolve(OrderItem source, OrderItemDto destination, string destMember, ResolutionContext context)
            {
                if (!string.IsNullOrEmpty(source.ItemOrdered.PictureUrl))
                    return this.configuration["ApiUrl"] + source.ItemOrdered.PictureUrl;

                return null;

            }
        }

    }

