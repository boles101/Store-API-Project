﻿using Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Text;

namespace APIAss1.Helpers
{
    public class CachedAttribute : Attribute, IAsyncActionFilter
    {
        private readonly int _TimeToLiveInSec;
        public CachedAttribute(int TimeToLiveInSec)
        {
            _TimeToLiveInSec = TimeToLiveInSec;
        }
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var cachedService = context.HttpContext.RequestServices.GetRequiredService<IResponseCacheService>();

            var cacheKey = GenerateCacheKeyFromRequest(context.HttpContext.Request);

            var cacheResponse = await cachedService.GetCachedResponse(cacheKey);
            if(!string.IsNullOrEmpty(cacheResponse)) 
            {
                var contentResult = new ContentResult()
                {
                    Content = cacheResponse,
                    ContentType = "application/json",
                     StatusCode = 200
                };

                context.Result = contentResult;

                return;
            }

            var excutedContext = await next();

            if (excutedContext.Result is OkObjectResult okObjectResult) 
                await cachedService.cacheResponseAsync(cacheKey,okObjectResult.Value,TimeSpan.FromSeconds(_TimeToLiveInSec));
        }

        private string GenerateCacheKeyFromRequest(HttpRequest request) 
        {
            var KeyBuilder = new StringBuilder();
            KeyBuilder.Append($"{request.Path}");

            foreach (var (key,value) in request.Query.OrderBy(x=>x.Key))
                 KeyBuilder.Append($"|{key}-{value}");

            return KeyBuilder.ToString();   
        }
    }
}
