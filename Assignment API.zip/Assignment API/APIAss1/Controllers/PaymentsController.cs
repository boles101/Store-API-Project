﻿using APIAss1.ResponseModule;
using Core.Entities;
using Core.Entities.OrderAggregate;
using Core.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Stripe;

namespace APIAss1.Controllers
{

    public class PaymentsController : BaseController
    {
        private readonly IPaymentService _paymentService;
        private readonly ILogger<PaymentsController> _logger;
        private const string Whsecret = "whsec_73cca8e728e172ff4b34725ca3ab4203d213fc3c7cdce5a5f01b4ca065c9aaf6";

        public PaymentsController(
            IPaymentService paymentService
           ,ILogger<PaymentsController>logger)
        {
            _paymentService = paymentService;
            _logger = logger;
        }

        [HttpPost("basketId")]
        public async Task<ActionResult<CustomerBasket>> CreateOrUpdatePaymentIntnet(string basketId)
        {
            var basket = await _paymentService.CreateOrUpdatePaymentIntent(basketId);

            if (basket == null)
                return BadRequest(new ApiResponse(400));
            return Ok(basket);
        }

        [HttpPost("webhook")]
        public async Task<IActionResult> Index()
        {
            var json = await new StreamReader(HttpContext.Request.Body).ReadToEndAsync();
            try
            {
                var stripeEvent = EventUtility.ConstructEvent(json,
                    Request.Headers["Stripe-Signature"], Whsecret);
                PaymentIntent intent;
                Order order;

                switch (stripeEvent.Type)
                {
                    case "payment_intent.payment_failed":
                        intent = (PaymentIntent)stripeEvent.Data.Object;
                        _logger.LogInformation("Payment Failed : ", intent.Id);
                        order = await _paymentService.UpdateOrderPaymentFailed(intent.Id);
                        _logger.LogInformation("Payment Failed : ", order.Id);
                        break;
                    case "payment_intent.succeeded":
                        intent = (PaymentIntent)stripeEvent.Data.Object;
                        _logger.LogInformation("Payment Succeded : ", intent.Id);
                        order = await _paymentService.UpdateOrderPaymentSucceded(intent.Id);
                        _logger.LogInformation("Order updated to payment  Recieved : ", order.Id);
                        break;
                }
                return Ok();
            }
            catch (StripeException e)
            {
                return BadRequest(new ApiResponse(400, "U Made a bad request "));
            }
        }
    }



}

