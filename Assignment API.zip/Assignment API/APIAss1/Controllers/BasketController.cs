﻿using APIAss1.Dtos;
using AutoMapper;
using Core.Entities;
using Core.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace APIAss1.Controllers
{

    public class BasketController : BaseController
    {
        private readonly IBasketRepository _basketRepository;
        private readonly IMapper _mapper;

        public BasketController(IBasketRepository basketRepository, IMapper mapper)
        {
            _basketRepository = basketRepository;
            _mapper = mapper;
        }

        #region Get Basket 
        [HttpGet("GetBasket")]
        public async Task<ActionResult<CustomerBasket>> GetBasketById(string id)
        {
            var basket = await _basketRepository.GetBasketAsync(id);
            return Ok(basket ?? new CustomerBasket(id));

        }

        #endregion

        #region Update Basket
        [HttpPost("UpdateBasket")]
        public async Task<ActionResult<CustomerBasket>> UpadateBasket(CustomerBasketDto customerBasketDto)
        {
            var basket = _mapper.Map<CustomerBasket>(customerBasketDto);
            var UpdatedBasket = await _basketRepository.UpdateBasketAsync(basket);
            return Ok(UpdatedBasket);
        }
        #endregion        

        #region Delete Basket

        [HttpDelete("DeleteBasket")]
        public async Task DeleteBaket(string id)

        => await _basketRepository.DeleteBasketAsync(id);

        #endregion
    }
}
