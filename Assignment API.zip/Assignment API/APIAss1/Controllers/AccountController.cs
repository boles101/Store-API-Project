﻿using APIAss1.Dtos;
using APIAss1.Extensions;
using APIAss1.ResponseModule;
using AutoMapper;
using Core.Entities.Identity;
using Core.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace APIAss1.Controllers
{
    public class AccountController : BaseController
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly SignInManager<AppUser> _signInManager;
        private readonly ITokenService _tokenService;
        private readonly IMapper _mapper;

        public AccountController(UserManager<AppUser> userManager
                                ,SignInManager<AppUser> signInManager
                                ,ITokenService tokenService
                                ,IMapper mapper)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _tokenService = tokenService;
            _mapper = mapper;
        }

        [Authorize]
        [HttpGet("GetUser")]
        public async Task<ActionResult<UserDto>> GetCurrentUser()
        {
            //var email= User.FindFirstValue(ClaimTypes.Email);
            var email = HttpContext.User.RetreiveEmailFromPrinciple();
            var user = await _userManager.FindByEmailAsync(email); 

            if (user == null) 
                return NotFound(new ApiResponse(404,"Email not Found"));
            return new UserDto()
            {
                Email = email,
                DisplayName = user.DisplayName,
                Token = _tokenService.CreateToken(user)
            };
        }

        [HttpPost("LogIn")]
        public async Task<ActionResult<UserDto>> Login(LoginDto  loginDto)
        {
            var user = await _userManager.FindByEmailAsync(loginDto.Email);
            if (user == null)
                return Unauthorized(new ApiResponse(401));

            var result = await _signInManager.CheckPasswordSignInAsync(user, loginDto.Password,false);
            if(!result.Succeeded)
                return Unauthorized(new ApiResponse(401));
            return new UserDto
            {
                Email = user.Email,
                DisplayName = user.DisplayName,
                Token = _tokenService.CreateToken(user)
            };
        }

        [HttpPost("Register")]
        public async Task<ActionResult<UserDto>> Register(RegisterDto registerdto)
        {
            if (CheckEmailExistsAsync(registerdto.Email).Result.Value)
            {
                return new BadRequestObjectResult(new ApiValidationErrrorResponse
                {
                    Errors = new[]
                    {
                        "Email Already Exists"
                    }
                }); 
            }
            var user = new AppUser()
            {
                DisplayName = registerdto.DisplayName,
                Email = registerdto.Email,
                UserName = registerdto.Email,
            };
            var result = await _userManager.CreateAsync(user, registerdto.Password);

            if (!result.Succeeded)
                return BadRequest(new ApiResponse(400));

            return new UserDto
            {
                Email = user.Email,
                DisplayName = user.DisplayName,
                Token = _tokenService.CreateToken(user)
            };
        }

        [HttpGet("EmailExists")]
        public async Task<ActionResult<bool>> CheckEmailExistsAsync([FromQuery] string email)
        => await _userManager.FindByEmailAsync(email) != null;

        [Authorize]
        [HttpGet("GetAddress")]
        public async Task<ActionResult<AddressDto>> GetAddressAsync()
        {
            //var email= User.FindFirstValue(ClaimTypes.Email);
            var email = HttpContext.User.RetreiveEmailFromPrinciple();
            var user = await _userManager.Users.Include(x =>x.Address)
                                               .SingleOrDefaultAsync(x=>x.Email == email);
            var mappedAddress = _mapper.Map<AddressDto>(user.Address);
            return Ok(mappedAddress);
        }

        [Authorize]
        [HttpPost("UpdateUserAddress")]
        public async Task<ActionResult<AddressDto>> UpdateUserAddress(AddressDto addressDto)
        {
            //var email= User.FindFirstValue(ClaimTypes.Email);
            var email = HttpContext.User.RetreiveEmailFromPrinciple();
            var user = await _userManager.Users.Include(x => x.Address)
                                               .SingleOrDefaultAsync(x => x.Email == email);

            user.Address = _mapper.Map<Address>(addressDto);

            var result = await _userManager.UpdateAsync(user);

            if (!result.Succeeded)
                return BadRequest(new ApiResponse(400));

            return Ok(_mapper.Map<AddressDto>(addressDto));

        }


    }
}
