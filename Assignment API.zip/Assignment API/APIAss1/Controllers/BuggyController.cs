﻿//using APIAss1.ResponseModule;
//using Infrastructure.Context;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;

//namespace APIAss1.Controllers
//{

//    public class BuggyController : BaseController
//    {
//        private readonly StoreDbContext context;

//        public BuggyController(StoreDbContext context)
//        {
//            this.context = context;
//        }



//        [HttpGet("notFound")]
//        documenting the error response
//        [ProducesResponseType(StatusCodes.Status200OK)]
//        [ProducesResponseType(StatusCodes.Status404NotFound)]
//        public ActionResult GetNotFoundRequest()
//        {
//            var Something = this.context.Products.Find(100);

//            if (Something == null)
//                return NotFound(new ApiResponse(404));
//            return Ok();
//        }

//        [HttpGet("badRequest")]
//        public ActionResult GetBadRequest()
//        {
//            return BadRequest(new ApiResponse(400));
//        }
//    }
//}
