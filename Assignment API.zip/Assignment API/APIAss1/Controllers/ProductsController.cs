﻿using APIAss1.Dtos;
using APIAss1.Helpers;
using APIAss1.ResponseModule;
using AutoMapper;
using Core.Entities;
using Core.Interfaces;
using Core.Specifications;
using Infrastructure.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace APIAss1.Controllers
{

    public class ProductsController : BaseController
    {
        //private readonly IUnitOfWork<Product> ProductRepository;
        //private readonly IGenericRepository<ProductBrand> productBrandRepository;
        //private readonly IGenericRepository<productType> productTypeRepository;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper mapper;

        //private readonly IProductRepository productRepository;

        public ProductsController(

            /*IProductRepository productRepository*/
            //IGenericRepository<Product> productRepository,
            //IGenericRepository<ProductBrand> productBrandRepository,
            //IGenericRepository<productType> productTypeRepository
            IUnitOfWork unitOfWork,
            IMapper mapper)

        {
            //this.productRepository = productRepository;
           // this.ProductRepository = productRepository;
           //this.productBrandRepository = productBrandRepository;
           // this.productTypeRepository = productTypeRepository;


            _unitOfWork = unitOfWork;
            this.mapper = mapper;
        }

        [HttpGet("GetProducts")]
        [Cached(10)]
        public async Task<ActionResult<Pagination<ProductDto>>> GetProducts([FromQuery]ProductSpecPrams productSpec)
        {
            var specs = new ProductsWithTypeAndBrandsSpecification(productSpec);

            var CountSpec = new ProductWithFiltersForSpecifications(productSpec);

            var totalItems = await _unitOfWork.Repository<Product>().CountAsync(specs);

            var products = await _unitOfWork.Repository<Product>().ListAsync(specs);

            var mappedProduct = this.mapper.Map<IReadOnlyList<ProductDto>>(products);

            var PaginatedData = new Pagination<ProductDto>(productSpec.PageIndex, productSpec.PageSize,totalItems ,mappedProduct );

            
            return Ok(PaginatedData); 
        }
            

        [HttpGet("GetProduct")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse),StatusCodes.Status404NotFound)]
        
        public async Task<ActionResult<ProductDto>> GetProducts(int id)
        {
            var specs = new ProductsWithTypeAndBrandsSpecification(id);

            var product = await _unitOfWork.Repository<Product>().GetEntityWithSpecification(specs);

            if(product == null) 
                return NotFound(new ApiResponse(404));
            var mappedproducts = this.mapper.Map<ProductDto>(product);

            return Ok(mappedproducts);
        }

        [HttpGet("brands")]
        [Cached(60)]

        public async Task<ActionResult<IReadOnlyList<ProductBrand>>> GetProductBrands()
        {
          return Ok( await _unitOfWork.Repository<ProductBrand>().ListAllAsync());
        }



        [HttpGet("types")]
        [Cached(60)]

        public async Task<ActionResult<IReadOnlyList<productType>>> GetProductTypes()
        {
            return Ok(await _unitOfWork.Repository<productType>().ListAllAsync());
        }






    }
}
