﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace APIAss1.Dtos
{
    public class RegisterDto
    {
        [Required]
        public string DisplayName { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        [RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^\\da-zA-Z]).{6,}$"
        , ErrorMessage = "password must have 1 uppercase , 1 lowercase, 1 number 1, alphanumeric at least 6 chars ")]
        public string Password { get; set; }

    }
}
