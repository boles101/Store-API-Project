﻿using Core.Entities.OrderAggregate;

namespace APIAss1.Dtos
{
    public class OrdeDto
    {
        public string BasketId { get; set; }
        public int  DeliveryMethodId { get; set; }
        public ShippingAddressDto Address{ get; set; }
    }
}
