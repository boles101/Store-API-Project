﻿using System.Security.Claims;

namespace APIAss1.Extensions
{
    public static class ClaimsPrincipleExtentions
    {
        public static string RetreiveEmailFromPrinciple(this ClaimsPrincipal user)
              =>  user.FindFirstValue(ClaimTypes.Email);
    }
}
