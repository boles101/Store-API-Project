﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
namespace Core.Entities.OrderAggregate
{
    public class OrderConfiguration : IEntityTypeConfiguration<Order>
    {
        public void Configure(EntityTypeBuilder<Order> builder)
        {
            builder.OwnsOne(d => d.ShippedToAddress, a => a.WithOwner());

            builder.Property(s => s.OrderStatus)
                .HasConversion(status => status.ToString(),
                value => (OrderStatus)Enum.Parse(typeof(OrderStatus),value)
                );
            builder.HasMany(order => order.OrderItems).WithOne().OnDelete(DeleteBehavior.Cascade);
        }
    }
}
