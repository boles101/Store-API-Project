﻿using Core.Entities.OrderAggregate;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Interfaces
{
    public interface IOrderService
    {
        Task<Order> CreateOrderAsync(string buyerEmail, int deliveryMethodId, string basketId, ShippingAddress address);
        Task<IReadOnlyList<Order>> GetOrdersForUsersAsync(string buyerEmail);
        Task<Order> GetOrderByIdAsync(int id, string buyerEmail); 
        Task<IReadOnlyList<DeliveryMethod>>GetDeliveryMethodsAsync();  
    }
}
