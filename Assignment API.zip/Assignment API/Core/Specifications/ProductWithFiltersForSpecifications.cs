﻿using Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Specifications
{
    public class ProductWithFiltersForSpecifications : BaseSpecification<Product>
    {
        public ProductWithFiltersForSpecifications(ProductSpecPrams productSpecPrams)
        : base(product =>
             (string.IsNullOrEmpty(productSpecPrams.Search) || product.Name.ToLower().Contains(productSpecPrams.Search)) &&
             (!productSpecPrams.BrandId.HasValue || product.ProductBrandId == productSpecPrams.BrandId) &&
             (!productSpecPrams.TypeId.HasValue || product.ProductTypeId == productSpecPrams.TypeId)
              )
        {

        }


    }
}
