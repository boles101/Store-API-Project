﻿using Core.Entities;
using Core.Entities.OrderAggregate;
using Infrastructure.Context;
using Microsoft.EntityFrameworkCore.Migrations.Operations;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Infrastructure.Data
{
    public   class StoreDbContextSeed
    {
        public static async Task SeedAsync(StoreDbContext context, ILoggerFactory loggerFactory)
        {
			try
			{
				if (context.ProductBrands != null && !context.ProductBrands.Any())
				{
					var brandData = File.ReadAllText("D:/Boles/School/ASP.Net Course/09 ASP Core API/Session 01/Ass1 API/Infrastructure/SeedData/brands.json");
					var brands = JsonSerializer.Deserialize<List<ProductBrand>>(brandData);

                    foreach (var item in brands)
						context.ProductBrands.Add(item);

					await context.SaveChangesAsync();
                }

                if (context.ProductTypes != null && !context.ProductTypes.Any())
                {
                    var typesData = File.ReadAllText("D:/Boles/School/ASP.Net Course/09 ASP Core API/Session 01/Ass1 API/Infrastructure/SeedData/types.json");
                    var types = JsonSerializer.Deserialize<List<productType>>(typesData);

                    foreach (var type in types)
                        context.ProductTypes.Add(type);

                    await context.SaveChangesAsync();
                }


                if (context.Products != null && !context.Products.Any())
                {
                    var productData = File.ReadAllText("D:/Boles/School/ASP.Net Course/09 ASP Core API/Session 01/Ass1 API/Infrastructure/SeedData/products.json");
                    var products = JsonSerializer.Deserialize<List<Product>>(productData);

                    foreach (var product in products)
                        context.Products.Add(product);

                    await context.SaveChangesAsync();
                }

                if (context.DeliveryMethods != null && !context.DeliveryMethods.Any())
                {
                    var DeliveryMethodsData = File.ReadAllText("../Infrastructure/SeedData/delivery.json");
                    var DeliveryMethods = JsonSerializer.Deserialize<List<DeliveryMethod>>(DeliveryMethodsData);

                    foreach (var methods in DeliveryMethods)
                        context.DeliveryMethods.Add(methods);

                    await context.SaveChangesAsync();
                }


            }
			catch (Exception ex)
			{
                var logger = loggerFactory.CreateLogger<StoreDbContextSeed>();
                logger.LogError(ex.Message);
			}

        }
    }
}
