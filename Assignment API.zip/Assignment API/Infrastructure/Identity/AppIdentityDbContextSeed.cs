﻿using Core.Entities;
using Core.Entities.Identity;
using Microsoft.AspNetCore.Identity;
namespace Infrastructure.Identity
{
    public class AppIdentityDbContextSeed 
    {
        public static async Task SeedUserAsync(UserManager<AppUser> userManager)
        {
            if (!userManager.Users.Any())
            {
                var user = new AppUser()
                {
                    DisplayName = "John",
                    Email = "John@gmail.com",
                    UserName = "John@gmail.com",
                    Address = new Address()
                    {
                        FirstName = "John",
                        LastName = "Doe",
                        Street = "10 st",
                        City = "Hurghada",
                        State = "Red Sea",
                        ZipCode = "1215XS",

                    }
                };
                await userManager.CreateAsync(user,"Password123!");
            }

        }
    }
}
